package com.victtech.cfapp.fragment;

import android.support.v4.app.Fragment;

/**
 * Created by Richard on 2018/1/18.
 */

public class ChuFangBaseFragment extends Fragment {
    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
